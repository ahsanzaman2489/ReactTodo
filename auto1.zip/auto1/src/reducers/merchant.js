import {handleActions} from 'redux-actions'

import gravatar from 'gravatar';

let initialState = [];

export default handleActions({
  'SET_INITIAL_STATE' (state, action) {

    state = [
      ...state,
      ...action.payload
    ];
    return state;
  },
  'CREATE' (state, action) {
    action.payload = {
      ...action.payload,
      avatarUrl: gravatar.url(action.payload.email, {
        s: '20',
        r: 'pg',
        d: 'retro',
        protocol: 'http'
      }, true),
      id: state.length + 1,
      bids: []
    }
    state = [
      ...state,
      action.payload
    ]

    console.log(state)
    return state;
  },
  'EDIT' (state, action) {
    const {entity, merchantsId, newValue} = action.payload;

    state.filter(item => {
      if (item.id === merchantsId) {
        return item[entity] = newValue;
      }
    });
    state = [...state]
    return state;
  },
  'DELETE' (state, action) {
    const selectedItem = state.findIndex(item => item.id == action.payload);
    state.splice(selectedItem, 1);
    state = [...state]
    return state;
  }
}, initialState);
