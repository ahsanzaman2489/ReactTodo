import {routerReducer as routing} from 'react-router-redux'
import {combineReducers} from 'redux';
import merchant from './merchant';

export default combineReducers({routing, merchant})
