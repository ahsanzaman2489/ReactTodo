import React from 'react';

import '../../node_modules/bootstrap/dist/css/bootstrap.css';
import './App.css';
import TABLE from '../components/table';
import Details from '../container/details';

import {Router, Route, browserHistory, IndexRoute} from 'react-router';
import {syncHistoryWithStore} from 'react-router-redux';
import {Provider} from 'react-redux';

import configureStore from '../store/configureStore';

const store = configureStore();
const history = syncHistoryWithStore(browserHistory, store)

class App extends React.Component {

  componentDidMount() {
    fetch('/mockData.json').then((response => {
      return response.json()
    })).then(json => {
      store.dispatch({type: 'SET_INITIAL_STATE', payload: json})
    });
  }
  render() {
    return (
      <div className="container">
        <Provider store={store}>
          <Router history={history}>
            <Route path="/" component={TABLE}>
              <Route path="/page/(:page)" component={TABLE}/>
            </Route>
            <Route path="/merchant" component={Details}/>
          </Router>
        </Provider>
      </div>
    );
  }

}

export default App;
