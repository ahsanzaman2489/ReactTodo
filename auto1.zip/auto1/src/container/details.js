/**
 * Created by ahsan.zaman on 06/11/2017.
 */
import React, {Component} from 'react';

import Detail from '../components/detail'
import {connect} from 'react-redux';

class Details extends Component {

  render() {
    const {merchants} = this.props;
    return (
      <div>
        {merchants.map((item, index) => {
          if (item.id == this.props.location.query.id) {
            return (<Detail key={index} merchant={item}/>)
          }
        })}
      </div>
    )
  }
}
const mapStateToProps = (state) => {
  return {merchants: state.merchant};
}

export default connect(mapStateToProps)(Details);
