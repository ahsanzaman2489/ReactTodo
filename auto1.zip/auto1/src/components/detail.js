/**
 * Created by ahsan.zaman on 06/11/2017.
 */
import React, {Component} from 'react';

class Detail extends Component {

  extractDate = (timeStamp) => {

    const date = new Date(parseInt(timeStamp));
    const newDate = date.getDate() + '/' + (date.getMonth() + 1) + '/' + date.getFullYear();
    return newDate;
  }

  render() {
    const {merchant} = this.props;

    return (
      <div>
        <ul className="list-group">
          <li className="list-group-item">Avatar :
            <img src={merchant.avatarUrl}/></li>
          <li className="list-group-item">First Name : {merchant.firstName}</li>
          <li className="list-group-item">Last Name : {merchant.lastName}</li>
          <li className="list-group-item">phone : {merchant.phone}</li>
          <li className="list-group-item">email : {merchant.email}</li>
          <li className="list-group-item">premium : {merchant.hasPremium
              ? 'Yes'
              : 'No'}</li>
        </ul>

        <h1>Bids</h1>
        <table className="table table-hover">
          <thead>
            <tr>
              <th>Bid Id</th>
              <th>Car Title</th>
              <th>Amount</th>
              <th>Created</th>
            </tr>
          </thead>
          <tbody>
            {merchant.bids.length > 0 && merchant.bids.map(item => {
              return (
                <tr key={item.id}>
                  <th>{item.id}</th>
                  <td>{item.carTitle}</td>
                  <td>${item.amount}</td>
                  <td>{this.extractDate(item.created)}</td>
                </tr>
              )
            })}
            {merchant.bids.length == 0 && <tr>
              <td>No Data</td>
            </tr>}
          </tbody>
        </table>
      </div>
    )
  }
}
export default Detail;
