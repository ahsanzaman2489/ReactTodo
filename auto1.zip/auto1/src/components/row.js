/**
 * Created by ahsan.zaman on 06/11/2017.
 */
import React from 'react';
import {Link} from 'react-router';

export default class Row extends React.Component {
  render() {
    const {merchant, doubleClickHandler, removeHandler} = this.props;
  
    return (
      <tr>
              <td >{merchant.id}</td>
              <td ><img src={merchant.avatarUrl} alt=""/></td>
              <td>
                <p onDoubleClick={doubleClickHandler.bind(this, merchant, 'firstName')}>{merchant.firstName}</p>
              </td>
              <td>
                <p onDoubleClick={doubleClickHandler.bind(this, merchant, 'lastName')}>{merchant.lastName}</p>
              </td>
              <td>
                <p onDoubleClick={doubleClickHandler.bind(this, merchant, 'phone')}>{merchant.phone}</p>
              </td>
              <td>
                <p onDoubleClick={doubleClickHandler.bind(this, merchant, 'email')}>{merchant.email}</p>
              </td>
              <td>
                <p>{merchant.bids.length}</p>
              </td>
              <td>
                <Link to={{
                  pathname: '/merchant',
                  query: {
                    id: merchant.id
                  }
                }}>
                  <i className='glyphicon glyphicon-eye-open' title="View"></i>
                </Link>

                <i onClick={() => removeHandler(merchant.id)} className='glyphicon glyphicon-remove' title="Remove"></i>
              </td>

        </tr>
    )
  }
}
