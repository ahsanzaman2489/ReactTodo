import React, {Component} from 'react';
import {bindActionCreators} from 'redux';
import Actions from '../actions';
import {connect} from 'react-redux';
import Row from './row';
import Pagination from './pagination';
import $ from 'jquery/dist/jquery.min';
import 'bootstrap/dist/js/bootstrap.min';
import {browserHistory} from 'react-router';

class Table extends Component {

  constructor() {
    super();
    this.state = {
      newMerchant: {
        firstName: '',
        lastName: '',
        phone: '',
        email: '',
        hasPremium: false
      }
    }
  }

  getPageIndexes = (options, merchants) => {

    let startingIndex;
    let merchantsToShow = [];


    if(options.totalItems < options.itemPerPage) options.itemPerPage = options.totalItems;

    startingIndex = (options.currentPage - 1) * options.itemPerPage;

    if(options.currentPage == options.totalPages){
      for (let i = startingIndex; i < options.totalItems; i++) {
        merchantsToShow.push(merchants[i]);
      }
    }else{
      for (let i = startingIndex; i < startingIndex + options.itemPerPage; i++) {
        merchantsToShow.push(merchants[i]);
      }
    }

    if(options.currentPage > options.totalPages) {
        merchantsToShow =[];
     }
       return merchantsToShow;
    }

  getTotalPages(totalItems,itemPerPage){
    if(totalItems%itemPerPage == 0){
        return totalItems/itemPerPage;
    }else{
        return parseInt(totalItems/itemPerPage) + 1;
    }

  }
  render() {

    const {merchants, actions} = this.props;
    const pagination = {
      itemPerPage: 3,
      currentPage: parseInt(this.props.params.page),
      totalItems: this.props.merchants.length,
      totalPages: this.getTotalPages(this.props.merchants.length ,3)
    }
    const merchantPerPage = this.getPageIndexes(pagination, merchants);

    return (
      <div>
        <div className="row">
          <button type="button" className="btn btn-success pull-right" data-toggle="modal" data-target="#addModal">Add
          </button>
        </div>

        <div className="modal fade" id="addModal" tabIndex="-1" role="dialog" aria-labelledby="addModal">
          <div className="modal-dialog" role="document">
            <div className="modal-content">
              <div className="modal-header">
                <button type="button" className="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <h4 className="modal-title" id="myModalLabel">Add New Merchant</h4>
              </div>
              <form onSubmit={this._submitHandler}>
                <div className="modal-body">

                  <div className="form-group">
                    <label>First Name</label>
                    <input type="text" className="form-control" name="firstName" value={this.state.newMerchant.firstName} onChange={this._onChangeHandler} required/>
                  </div>
                  <div className="form-group">
                    <label>Last Name</label>
                    <input type="text" className="form-control" name="lastName" value={this.state.newMerchant.lastName} onChange={this._onChangeHandler} required/>
                  </div>

                  <div className="form-group">
                    <label>phone</label>
                    <input required type="phone" className="form-control" name="phone" value={this.state.newMerchant.phone} onChange={this._onChangeHandler}/>
                  </div>

                  <div className="form-group">
                    <label>email</label>
                    <input required type="email" className="form-control" name="email" value={this.state.newMerchant.email} onChange={this._onChangeHandler}/>
                  </div>

                  <div className="form-group">
                    <label>Premium</label>
                    <select name='hasPremium' onChange={this._onChangeHandler} value={this.state.newMerchant.hasPremium}>
                      <option value='true'>yes</option>
                      <option value='false'>no</option>
                    </select>
                  </div>

                </div>
                <div className="modal-footer">
                  <button type="button" className="btn btn-default" data-dismiss="modal">Close
                  </button>
                  <button type="submit" className="btn btn-primary">Save changes</button>
                </div>
              </form>
            </div>
          </div>
        </div>

        <table className="table table-hover">
          <thead>
            <tr>
              <th>#</th>
              <th>Avatar</th>
              <th>First Name</th>
              <th>Last Name</th>
              <th>phone</th>
              <th>email</th>
              <th>Bids</th>
              <th>actions</th>
            </tr>
          </thead>
          <tbody>
            {merchantPerPage[0] != undefined && merchantPerPage.map((item,index)=>{
              console.log(item)
              return (<Row key={index} merchant={item} doubleClickHandler={this._doubleClickHandler} removeHandler={this._removeHandler}/>)
            })}
          </tbody>
        </table>
        <Pagination options={pagination} pageItems={merchantPerPage.length} history={this.props.history}/>
      </div>
    );
  }

  _onChangeHandler = (e) => {
    e.preventDefault();
    const res = {};

    if (e.target.value == 'true' || e.target.value == 'false') {
      res[e.target.name] = (e.target.value == 'true');
    } else {
      res[e.target.name] = e.target.value;

    }
    this.setState({
      newMerchant: {
        ...this.state.newMerchant,
        ...res
      }
    });

  }
  _submitHandler = (e) => {
    e.preventDefault();
    this.props.actions.merchants.CREATE(this.state.newMerchant);
    this.setState({
      newMerchant: {
        firstName: '',
        lastName: '',
        phone: '',
        email: '',
        hasPremium: false
      }
    });
  }

  _doubleClickHandler = (merchant, clickedEntity, event) => {
    event.preventDefault();
    const el = $(event.target);

    const currentValue = el.html();
    const editable = '<input type="text" class="editable" value="' + currentValue + '"/>';
    let newValue;

    if (el.find('.editable').length == 0) {
      el.html(editable);
      el.find('.editable').focus();

      el.find('.editable').keyup(e => {
        if (e.keyCode === 13) {
          newValue = e.currentTarget.value;
          if (currentValue != newValue) {
            this.props.actions.merchants.EDIT({newValue: newValue, merchantsId: merchant.id, entity: clickedEntity});
          } else {
            el.html(currentValue)
          }
          $(this).remove();
        } else if (e.keyCode === 27) {
          $(this).remove();
          el.html(currentValue)
        }
      })
    } else {
      return;
    }

  }

  _removeHandler = (id) => {
    this.props.actions.merchants.DELETE(id);
  }

}

const mapStateToProps = (state) => {
  return {merchants: state.merchant};
}

const mapDispatchToProps = (dispatch) => {
  return {
    actions: {
      merchants: bindActionCreators(Actions.merchant, dispatch)
    }

  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Table);
