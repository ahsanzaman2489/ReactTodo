import * as merchant from './merchant';

export default {
  merchant
}
