import {createAction} from 'redux-actions';

export const CREATE = createAction('CREATE');
export const EDIT = createAction('EDIT');
export const DELETE = createAction('DELETE');
export const SET_INITIAL_STATE = createAction('SET_INITIAL_STATE');
